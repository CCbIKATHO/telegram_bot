#!/bin/bash
python3.10 /home/asterisk/bot/bot.py
