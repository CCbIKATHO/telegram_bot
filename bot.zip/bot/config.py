token = 'API' #Use this token to access the HTTP API https://t.me/BotFather
admin = ['ID'] # Your user ID https://t.me/getmyid_bot Example for multiple administrators ['ID', 'ID', 'ID', 'ID']

dir1 = '/var/www/'
dir_backup = '/backup/' #path to the folder with the backup file